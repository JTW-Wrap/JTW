/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./page/**/*.html",
  ]
  ,
    theme: {
      extend: {},
    },
    plugins: [],
  }
  